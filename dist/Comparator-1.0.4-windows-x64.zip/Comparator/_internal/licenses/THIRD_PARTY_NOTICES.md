# Comparator runtime notices

This Windows bundle includes unmodified third-party runtime components.
Their licenses are provided below and in the accompanying files.
Application files are not code-signed.

PySide6, shiboken6 and Qt are used under LGPL version 3 where applicable.
You may replace their dynamically loaded libraries in _internal with
compatible modified libraries. Reverse engineering for debugging such
library modifications is permitted under their applicable licenses.
Qt source and component-specific notices: https://code.qt.io/
Qt licensing: https://doc.qt.io/qt-6/licensing.html
Qt for Python source: https://code.qt.io/pyside/

- PySide6-Essentials 6.12.0
- shiboken6 6.12.0
- Pillow 13.0.0
- Send2Trash 2.2.0
- pyinstaller 6.22.3

- Python 3.14.10
